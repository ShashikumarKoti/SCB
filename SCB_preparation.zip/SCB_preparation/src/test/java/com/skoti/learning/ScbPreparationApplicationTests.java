package com.skoti.learning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScbPreparationApplicationTests {

	@Test
	void contextLoads() {
	}

}
