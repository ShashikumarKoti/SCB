package com.skoti.learning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScbPreparationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScbPreparationApplication.class, args);
	}

}
