//package com.skoti.learning.controller;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.skoti.learning.TestServiceImpl;
//
//@RestController
//@RequestMapping("v1/api/scb/")
//public class TestController {
//
//	@Autowired
//	private TestServiceImpl testServiceImpl;
//
//	@GetMapping("findSecHighest/{listOfNumbers}")
//	public Integer getAllInts(@PathVariable("listOfNumbers") List<Integer> listOfNumbers) throws Exception {
//		return testServiceImpl.getSecondHighest(listOfNumbers);
//
//	}
//
//	@GetMapping("findSecHighestfromArray/{arrayOfNumbers}")
//	public Integer getAllArrayInts(@PathVariable("arrayOfNumbers") Integer[] arrayOfNumbers) throws Exception {
//		return testServiceImpl.getSecondHighestFromArrays(arrayOfNumbers);
//	}
//}
