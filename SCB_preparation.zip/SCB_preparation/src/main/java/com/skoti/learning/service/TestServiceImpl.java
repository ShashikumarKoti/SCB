package com.skoti.learning.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skoti.learning.utility.TestUtility;

@Service
public class TestServiceImpl {

	@Autowired
	private TestUtility testUtility;

	public Integer getSecondHighest(List<Integer> listOfnumbers) throws Exception {
		if(listOfnumbers.size()==0) {
			throw new Exception();
		}
		return testUtility.findSecondHighest(listOfnumbers);

	}

	public Integer getSecondHighestFromArrays(Integer[] arrayOfnumbers) throws Exception {
		if(arrayOfnumbers.length==0) {
			throw new Exception();
		}
		return testUtility.findSecondHighestfromArray(arrayOfnumbers);
	}
}
