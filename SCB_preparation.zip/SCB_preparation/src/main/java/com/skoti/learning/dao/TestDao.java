package com.skoti.learning.dao;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class TestDao {

	public List<Integer> numbers(){
		
		return Arrays.asList(77,44,55,22,30,27,44);
	}
}
