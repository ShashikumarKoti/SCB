package com.skoti.learning.utility;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

@Component
public class TestUtility {

	public Integer findSecondHighest(List<Integer> listOfnumbers) {

		Optional<Integer> secondHighest = listOfnumbers.stream().sorted(Comparator.reverseOrder()).limit(2).skip(1)
				.findFirst();
		if (secondHighest.isPresent()) {
			return secondHighest.get();
		}
		return null;
	}

	public Integer findSecondHighestfromArray(Integer[] arrayOfnumbers) {
		List<Integer> asList = Arrays.asList(arrayOfnumbers);
		Optional<Integer> secondHighest = asList.stream().sorted(Comparator.reverseOrder()).limit(2).skip(1)
				.findFirst();
		if (secondHighest.isPresent()) {
			return secondHighest.get();
		}
		return null;
	}

}
