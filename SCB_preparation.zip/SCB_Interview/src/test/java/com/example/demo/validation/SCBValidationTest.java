package com.example.demo.validation;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SCBValidationTest {

	@InjectMocks
	private SCBValidation scbValidation;
	
	@Test
	public void testWordValidation() {
		String word = "abscs";
		scbValidation.validateWord(word);
	}
	
	@Test
	public void testArrayValidation() {
		Integer[] arr = {1,2,3,4,5};
		scbValidation.validateArray(arr);
	}
}
