package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

import java.util.Arrays;
import java.util.Collection;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class JUnit5Tests {

	@BeforeAll
	static void setup() {
		System.out.println("@BeforeAll executed");
	}

	@BeforeEach
	void setupThis() {
		System.out.println("@BeforeEach executed");
	}

	@Test
	void myFirstTest() {
		assertEquals(2, 1 + 1);
	}

	@ParameterizedTest
	@ValueSource(strings = { "races", "radar", "aaaaa" })
	void palindromes(String candidate) {
		assertEquals(5, candidate.length());
	}

	@RepeatedTest(5)
	@ValueSource()
	void repeatedTestEx() {
		assertEquals(3, 2 + 1);
	}

	@TestFactory
	Collection<DynamicTest> dynamicTestsFromCollection() {
		return Arrays.asList(dynamicTest("1st dynamic test", () -> assertTrue(true)),
				dynamicTest("2nd dynamic test", () -> assertEquals(4, 2 * 2)));
	}

	@Test
	void whenAssertingArraysEquality_thenEqual() {
		char[] expected = { 'J', 'u', 'p', 'i', 't', 'e', 'r' };
		char[] actual = "Jupiter".toCharArray();

		assertArrayEquals(expected, actual, "Arrays should be equal");
	}

	@Test
	void whenAssertingConditions_thenVerified() {
		assertTrue(5 > 4, "5 is greater the 4");
		// assertTrue(null == null, "null is equal to null");
	}

	@Test
	void whenFailingATest_thenFailed() {
		// Test not completed
		fail("FAIL - test not completed");
	}
	
	@Test
	void givenMultipleAssertion_whenAssertingAll_thenOK() {
	    assertAll(
	      "heading",
	      () -> assertEquals(4, 2 * 2, "4 is 2 times 2"),
	      () -> assertEquals("java", "JAVA".toLowerCase())
	   //   () -> assertEquals(null, null, "null is equal to null")
	    );
	}

	@Tag("DEV")
	@Test
	void testCalcOne() {
		System.out.println("======TEST ONE EXECUTED=======");
		// Assertions.assertEquals(4, Calculator.add(2, 2));
	}

	@Tag("PROD")
	@Disabled
	@Test
	void testCalcTwo() {
		System.out.println("======TEST TWO EXECUTED=======");
		// Assertions.assertEquals(6, Calculator.add(2, 4));
	}

	@AfterEach
	void tearThis() {
		System.out.println("@AfterEach executed");
	}

	@AfterAll
	static void tear() {
		System.out.println("@AfterAll executed");
	}
}