package com.example.demo.service;

import static org.mockito.Mockito.mock;

import java.awt.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.validation.SCBValidation;

@SpringBootTest
public class SCBServiceTest {

	@InjectMocks
	private SCBService scbService;
	
	@Mock
	private SCBValidation scbValidation;
	
	@Test
	public void testSecondHighest() {
		mock(List.class);
		Integer [] arr = {1,2,3,4,5};
		scbService.getSecHighest(arr);
	}
	
	@Test
	public void testRemoveDupslicates() {
		String word = "aabscs";
		scbService.removeDups(word);
	}
	
//	@Test(expected = RuntimException.class){
//		String word = "";
//		scbService.removeDups(word);
//	}
}
