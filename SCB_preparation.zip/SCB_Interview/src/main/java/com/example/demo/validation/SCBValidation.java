package com.example.demo.validation;

import org.springframework.stereotype.Service;

@Service
public class SCBValidation {

	public void validateWord(String word) {
		if(word==null|| word.length()==0) {
			throw new RuntimeException("Input string cannot be empty");
		}
	}

	public void validateArray(Integer[] arr) {
		if(arr.length==0) {
			throw new RuntimeException("Input array cannot be empty");
		}
	}

}
