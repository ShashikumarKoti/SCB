package com.example.demo.service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.validation.SCBValidation;

@Service
public class SCBService {

	@Autowired
	private SCBValidation scbValidation;

	public Integer getSecHighest(Integer[] arr) {
		scbValidation.validateArray(arr);
		return findSecondHighest(arr);
	}

	public String removeDups(String word) {
		return removeDuplicates(word);
	}

	private String removeDuplicates(String word) {
		scbValidation.validateWord(word);
		StringBuilder sb = new StringBuilder();
		word.chars().distinct().forEach(c -> sb.append((char) c));
		return sb.toString();
	}

	private Integer findSecondHighest(Integer[] arr) {
		List<Integer> listOfNum = Arrays.asList(arr);
		Optional<Integer> num = listOfNum.stream().distinct().sorted(Comparator.reverseOrder()).limit(2).skip(1)
				.findFirst();
		if (num.isPresent()) {
			return num.get();
		}
		return null;
	}

}
