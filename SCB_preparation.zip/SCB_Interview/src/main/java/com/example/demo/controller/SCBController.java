package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.MessageService;
import com.example.demo.service.SCBService;

//Case:1
//Write a Java Program to find the second highest number in an array.
//Input: 14 46 92 47 45 92 52 48 36 66 85
//Output: 85

//Case2:
//Input : aabscs Output: absc
//Input : abcd Output: abcd


@RestController
//@RequestMapping("v1/api/scb/")
public class SCBController {

	@Autowired
	private SCBService scbService;
	
	 @Autowired
	  private MessageService messageService;
	
	@GetMapping("/secondHighest/{listOfNum}")
	public Integer findSecHighest(@PathVariable("listOfNum") Integer[] listOfNum) {
			return scbService.getSecHighest(listOfNum);
	}
	
	@GetMapping("/removeDups/{word}")
	public String removeDuplicates(@PathVariable("word") String word) {
		return scbService.removeDups(word);
	}
	
	@GetMapping("/hello")
	  public String sayHello(@RequestParam String user) {
	    return messageService.getSubscriptionMessage(user);
	  }
}
